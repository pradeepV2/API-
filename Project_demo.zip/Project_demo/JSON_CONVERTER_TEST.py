import requests
import os
from flask import Flask, jsonify
from glob import glob
from DECODER import get_tasks, image_result, unique_id
from Invoice_reader_format import json_output

app = Flask(__name__)

def raw_file():
    return requests.get(image_result)

def process_id():
    return requests.get(unique_id)

def output_file():
    return requests.get(json_output)

if __name__ == '__main__':
    app.run(debug=True)
