from flask import Flask
from flask_restful import Resource, Api
from flask_api import FlaskAPI

import io
import re
import os

import json
import numpy as np
import pandas as pd

import datetime as dt
import six

from glob import glob
from google.cloud import vision

from google.cloud import language
from google.cloud.language import enums
from google.cloud.language import types

import requests
import base64

#from file_encrypter import image_64_encode
#from Invoice_reader_format import json_output

# Set Google API authentication and set folder where images are stored
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'Banking-326c0d0e12c1.json'
client = vision.ImageAnnotatorClient()

app = Flask(__name__)

@app.route('/process_scan', methods=['GET', 'POST'])

def process_scan():
    #image=open('input_file.jpg', 'rb')
    #image_read = image.read()
    #image_64_encode = base64.encodebytes(image_read)

    content = base64.decodebytes(image_64_encode)

    response = client.document_text_detection({'content': content})  # [1]
    texts = response.text_annotations
    rendered_text = texts[np.argmax([len(t.description) for t in texts])].description.split('\n')

    corpus = [' '.join(rendered_text)]

    Data = information_extract(rendered_text)

    Data = pd.DataFrame(Data)

    Data = Data.transpose()
    Data

    Data.to_json('Invoice.json', orient='records', lines=False)

    with open('Invoice.json') as json_data:
        jsonresult = json_data.read()
    print(jsonresult)
    return jsonresult


def from_addr(rendered_text):
    regex = r"(From|From:)"

    for i in range(0, len(rendered_text)):
        matches = re.match(regex, rendered_text[i])
        if matches:
            render_a = []

            for j in range(1, 6):
                render_a.append(rendered_text[i + j])

    return render_a


def to_addr(rendered_text):
    regex = r"(To:)"

    for i in range(0, len(rendered_text)):
        matches = re.match(regex, rendered_text[i])
        if matches:
            render_b = []

            for j in range(1, 5):
                render_b.append(rendered_text[i + j])

    return render_b

def invoice(rendered_text):
    regex = r"(Invoice:)"

    for i in range(0, len(rendered_text)):
        matches = re.match(regex, rendered_text[i])
        if matches:
            render_c = []

            for j in range(1, 4):
                render_c.append(rendered_text[i + j])

    return render_c


def total(rendered_text):
    regex = r"(Total|Total:)"

    for i in range(0, len(rendered_text)):
        matches = re.match(regex, rendered_text[i])
        if matches:
            render_d = []

            for j in range(1, 2):
                render_d.append(rendered_text[i + j])

    return render_d



def information_extract(rendered_text):
    rendered = rendered_text

    to = to_addr(rendered)

    frm = from_addr(rendered)

    inv = invoice(rendered)

    tot = total(rendered)

    return pd.Series({'From': frm, 'To': to, 'Invoice_detail': inv, 'Total': tot})


if __name__ == '__main__':
    app.run(debug=True)