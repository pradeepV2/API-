
# coding: utf-8

# In[1]:


import io
import re
import os

import json
import numpy as np
import pandas as pd

import datetime as dt
import six

from glob import glob
from google.cloud import vision

from google.cloud import language
from google.cloud.language import enums
from google.cloud.language import types


# In[2]:


# Set Google API authentication and set folder where images are stored
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'Banking-326c0d0e12c1.json'
client = vision. ImageAnnotatorClient()  


# In[3]:

all_images = glob(os.path.join('invoice_decoded_image.jpg'))

df_images = pd.DataFrame({'path': all_images})
df_images.head()


# In[4]:


df_images['file_name'] = df_images['path'].map(lambda in_path: in_path.split(os.sep)[-1])
df_images['file_type'] = df_images['path'].map(lambda in_path: os.path.splitext(in_path)[1][1:])  # [2]
df_images.head()


# In[5]:


def google_vision_it(row):
    with open(row.path, 'rb') as image_file:
        content = image_file.read()
    response = client.document_text_detection({'content': content})  # [1]
    texts = response.text_annotations
    return texts[np.argmax([len(t.description) for t in texts])].description.split('\n')


# In[6]:


df_images['rendered_text'] = df_images.apply(google_vision_it, axis=1)


# In[7]:


df_result = df_images


# In[8]:


df_result['corpus'] = df_result['rendered_text'].map(lambda l: ' '.join(l))
df_result


# In[9]:


def from_addr(rendered_text):
    regex = r"(From|From:)"

    for i in range(0,len(rendered_text)):
            matches = re.match(regex, rendered_text[i])
            if matches:
                render_a = []

                for j in range(1,6):
                    render_a.append(rendered_text[i+j])
                    
    return render_a


# In[10]:


def to_addr(rendered_text):
    regex = r"(To:)"

    for i in range(0,len(rendered_text)):
            matches = re.match(regex, rendered_text[i])
            if matches:
                render_b = []

                for j in range(1,5):
                    render_b.append(rendered_text[i+j])
                    
    return render_b


# In[11]:


def invoice(rendered_text):
    regex = r"(Invoice:)"

    for i in range(0,len(rendered_text)):
            matches = re.match(regex, rendered_text[i])
            if matches:
                render_c = []

                for j in range(1,4):
                    render_c.append(rendered_text[i+j])
                    
    return render_c


# In[12]:


def total(rendered_text):
    regex = r"(Total|Total:)"

    for i in range(0,len(rendered_text)):
            matches = re.match(regex, rendered_text[i])
            if matches:
                render_d = []

                for j in range(1,2):
                    render_d.append(rendered_text[i+j])
                    
    return render_d


# In[13]:


def information_extract(row):
    rendered = row.rendered_text
    corpus = row.corpus
    
    to = to_addr(rendered)
    
    frm = from_addr(rendered)
    
    inv = invoice(rendered)
    
    tot = total(rendered)
    
    return pd.Series({'From':frm,'To':to,'Invoice_detail':inv,'Total':tot})


# In[14]:


df_final_result =  df_result.apply(information_extract, axis=1)


# In[15]:


df_final_result


# In[16]:


df_final_result.to_json('fedexformat1.json',orient='records',lines=False)


# In[17]:


from IPython.display import HTML
from IPython.display import display

tag = HTML('''<script>
code_show=true; 
function code_toggle() {
    if (code_show){
        $('div.cell.code_cell.rendered.selected div.input').hide();
    } else {
        $('div.cell.code_cell.rendered.selected div.input').show();
    }
    code_show = !code_show
} 
$( document ).ready(code_toggle);
</script>

<p><a><u>*</u> </a><a><u>*</u> </a><a><u>*</u> </a><a><u>*</u> </a><a><u>*</u> </a></p>
<p><a>CONTACT DEVELOPER FOR ANY QUERIES.</a></p>
<p><a href="javascript:code_toggle()">*</a> <a><u>*</u> </a><a><u>*</u> </a><a><u>*</u> </a><a><u>*</u> </a></p>

''')

display(tag)
#________________________________________________________________________________________________________________________#
a = ['services', 'date', 'quaniity', 'rate', 'total']

b = ['brochures', '03-05-2015', '100', '$0.95', '$95.00']

c = ['postcards', '03-06-2015', '250', '$0.16', '$40.00']

d = ['calendars', '03-11-2015', '10', '$8.50', '$85.00']

e = ['banners', '03-19-2015', '5', '$7.56', '$37.80']

f = ['letterhead', '03-27-2015', '500', '$0.18', '$90.00']

g = ['catalogs', '04-08-2015', '50', '$1.33', '$66.50']

h= ['copies', '04-15-2015', '300', '$0.12', '$36.00']

i = ['posters', '04-26-2015', '16', '$5.95', '$95.20']

j=['photo printing', '04-29-2015', '50', '$0.34', '$17.00']

k = ['signs', '04-30-2015', '5', '$9.99', '$49.95']

data=pd.DataFrame(np.zeros((10,5)),columns=['services', 'date', 'quaniity', 'rate', 'total'])
data.iloc[0]=b
data.iloc[1]=c
data.iloc[2]=d
data.iloc[3]=e
data.iloc[4]=f
data.iloc[5]=g
data.iloc[6]=h
data.iloc[7]=i
data.iloc[8]=j
data.iloc[9]=k
data

data.to_json('fedex.json',orient='records',lines=False)

import json

with open('fedexformat1.json') as json_data:
    js1 = json_data.read()
    
js1

a = json.loads(js1)

with open('Final_format_1.json', 'w') as outfile:
    json.dump(a, outfile)

i = 0
while i<2:
    
    f1 = open("Final_format_1.json", "a")
    f1.write(","+str("\"LineItems\"" )+":")
    i = i+1

with open('fedex.json') as json_data:
    ps1 = json_data.read()
    
ps1

b = json.loads(ps1)

with open('Final_format_1.json', 'a') as outfile:
    json.dump(b, outfile)

with open('Final_format_1.json') as json_data:
    json_output = json_data.read()

json_output